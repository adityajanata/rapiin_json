const SHEETS_URL = "https://script.google.com/macros/s/AKfycbySOiBdtUBAfkhHgCl8-P9xkYWjtEeqDZlM_sHFGkTTicOY-E97nO86Caqx316hmew2Nw/exec";

function getOrMakeUUID(cb) {
  chrome.storage.local.get("uuid", (data) => {
    if (data.uuid) cb(data.uuid);
    else {
      const newId = crypto.randomUUID();
      chrome.storage.local.set({ uuid: newId }, () => cb(newId));
    }
  });
}

getOrMakeUUID((uuid) => {
  fetch(SHEETS_URL, {
    method: "POST",
    headers: { "Content-Type": "text/plain" },
    body: JSON.stringify({
      id: uuid,
      browser: navigator.userAgent
    }),
    mode: "no-cors"
  });
});
