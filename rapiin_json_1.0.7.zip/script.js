const input = document.getElementById('input');
const output = document.getElementById('output');
const error = document.getElementById('error');
const formatBtn = document.getElementById('formatBtn');

// Function untuk cek apakah input JSON pretty atau minify
// function isPretty(jsonString) {
//   return (jsonString.match(/\n/g) || []).length > 0;
// }

function isPretty(jsonStr) {
  // Cek apakah JSON sudah pretty (ada newline & indentasi)
  // Simple check: ada \n dan spasi 2 atau 4 sebelum karakter non-spasi
  return /\n\s{2,}/.test(jsonStr);
}

// Reset styling output
function resetOutputStyle() {
  output.style.color = '';
  output.style.backgroundColor = '';
  output.style.borderColor = '';
}

// Apply success style (hijau)
function applySuccessStyle() {
  output.style.color = '#0f5132';
  output.style.backgroundColor = '#d1e7dd';
  output.style.borderColor = '#badbcc';
}

// Apply error style (merah)
function applyErrorStyle() {
  output.style.color = '#842029';
  output.style.backgroundColor = '#f8d7da';
  output.style.borderColor = '#f5c2c7';
}

// Saat input berubah
// input.addEventListener('input', function() {
//   try {
//     const obj = JSON.parse(input.value);

//     // Cek apakah input pretty
//     if (isPretty(input.value)) {
//       output.value = JSON.stringify(obj);
//     } else {
//       output.value = JSON.stringify(obj, null, 2);
//     }

//     error.textContent = '';
//     resetOutputStyle();
//   } catch (e) {
//     output.value = '';
//     error.textContent = 'Invalid JSON: ' + e.message;
//     applyErrorStyle();
//   }
// });

input.addEventListener('input', function() {
  try {
    const obj = JSON.parse(input.value);
    const fullyParsed = deepParse(obj);

    if (isPretty(input.value)) {
      output.value = JSON.stringify(fullyParsed);
    } else {
      output.value = JSON.stringify(fullyParsed, null, 2);
    }

    error.textContent = '';
    resetOutputStyle();
  } catch (e) {
    output.value = '';
    error.textContent = 'Invalid JSON: ' + e.message;
    applyErrorStyle();
  }
});



function tryParseNestedJson(value) {
  if (typeof value !== 'string') return value;

  try {
    const parsed = JSON.parse(value);
    // Kalau hasil parse masih string (nested lagi), parse terus
    return tryParseNestedJson(parsed);
  } catch {
    // Kalau gak bisa parse, berarti ini bukan JSON string, return apa adanya
    return value;
  }
}

// Fungsi rekursif yang merubah semua string nested JSON jadi objek
function deepParse(obj) {
  if (typeof obj === 'string') {
    return tryParseNestedJson(obj);
  }
  if (Array.isArray(obj)) {
    return obj.map(deepParse);
  }
  if (obj && typeof obj === 'object') {
    const result = {};
    for (const key in obj) {
      if (Object.hasOwnProperty.call(obj, key)) {
        result[key] = deepParse(obj[key]);
      }
    }
    return result;
  }
  return obj;
}


/////////////////////////////////////////////

// Tombol untuk copy output
formatBtn.addEventListener('click', function() {
  if (output.value) {
    navigator.clipboard.writeText(output.value)
      .then(() => {
        formatBtn.textContent = 'Copied!';
        applySuccessStyle();  // Kalau sukses, jadi hijau
        setTimeout(() => {
          formatBtn.textContent = 'Copy Output';
          resetOutputStyle(); // Balikin normal abis 1.5 detik
        }, 1500);
      })
      .catch(() => {
        error.textContent = 'Failed to copy!';
        applyErrorStyle(); // Kalau gagal copy, tetep merah
      });
  }
});
``


function pad(num) {
    return num.toString().padStart(2, '0');
  }

  function updateWaktu() {
    const now = new Date();

    const hari = pad(now.getDate());
    const bulanList = [
      'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
      'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
    ];
    const bulan = bulanList[now.getMonth()];
    const tahun = now.getFullYear();

    const jam = pad(now.getHours());
    const menit = pad(now.getMinutes());
    const detik = pad(now.getSeconds());

    const tanggalString = `${hari} ${bulan} ${tahun} ${jam}:${menit}:${detik}`;
    document.getElementById('tanggalWaktu').textContent = tanggalString;
  }

setInterval(updateWaktu, 1000);
updateWaktu(); // pertama kali jalan


async function fetchGitHubText() {
  try {
    const response = await fetch("https://raw.githubusercontent.com/adityajanata/shelter/main/hop.txt", {
      cache: "no-store"
    });
    if (!response.ok) throw new Error("Gagal ambil data");

    const text = await response.text();
    document.getElementById("github-quote").innerText = text;
  } catch (err) {
    console.error("Error ambil teks:", err);
    document.getElementById("github-quote").innerText = "Gagal ambil pesan 😢";
  }
}

fetchGitHubText(); // panggil saat halaman load

// CHECK UPDATE START
async function checkForUpdate() {

  function getBrowserType() {
    const ua = navigator.userAgent;
    if (ua.includes("Firefox")) return "firefox";
    if (ua.includes("Edg")) return "edge";
    if (ua.includes("Chrome")) return "chrome";
    return "other";
  }

  try {
    const response = await fetch("https://rapiin-json.vercel.app/extension-version.json", {
      cache: "no-store"
    });
    if (!response.ok) throw new Error("Gagal ambil versi dari server");

    const data = await response.json();
    const latest = data.version;
    const changelog = data.changelog || "";
    const current = chrome.runtime.getManifest().version;



    if (latest !== current) {
      if (confirm(`🔥 Versi baru tersedia!\n\nVersi kamu: ${current}\nVersi terbaru: ${latest}\n\nChangelog:\n${changelog}\n\nMau Download file yang terupdate?`)) {
        const browser = getBrowserType();
        let downloadUrl = "";
        if (browser === "firefox") {
          downloadUrl = `https://rapiin-json.vercel.app/bda2426706d544b0a717-${latest}.xpi`;
        } else if (browser === "chrome" || browser === "edge") {
          downloadUrl = `https://rapiin-json.vercel.app/rapiin_json_${latest}.zip`;
        } else {
          downloadUrl = `https://rapiin-json.vercel.app/rapiin_json_${latest}.zip`; // fallback
        }

        window.open(downloadUrl, "_blank");

      }
    } else {
      const browser = getBrowserType();
      alert(`✅ Rapiin JSON sudah versi terbaru di${browser} kamu!`);
    }
  } catch (e) {
    console.error(e);
    alert("❌ Gagal cek update");
  }

}

document.addEventListener("DOMContentLoaded", () => {
  document.getElementById("update-btn").addEventListener("click", checkForUpdate);
});

// CHECK UPDATE END


const updateBtn = document.getElementById("update-btn");

updateBtn.addEventListener("click", () => {
  // Mulai muter
  updateBtn.classList.add("spin");

  // Simulasi proses (misal 2 detik), abis itu stop muter
  setTimeout(() => {
    updateBtn.classList.remove("spin");
  }, 2000);

  // TODO: Tambahin fungsi check for update beneran di sini
});
