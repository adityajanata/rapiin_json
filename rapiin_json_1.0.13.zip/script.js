const input = document.getElementById('input');
const output = document.getElementById('output');
const error = document.getElementById('error');
const formatBtn = document.getElementById('formatBtn');
const updateBtn = document.getElementById("update-btn");
const quoteEl = document.getElementById("github-quote");

// --- UTILITAS UI ---
function pad(num) { return num.toString().padStart(2, '0'); }

// Update waktu gak perlu interval 1 detik kalau cuma buat info tanggal
// Cukup update pas dibuka aja, atau interval 60 detik biar ringan
function updateWaktu() {
  const now = new Date();
  const bulanList = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
  const tanggalString = `${pad(now.getDate())} ${bulanList[now.getMonth()]} ${now.getFullYear()} ${pad(now.getHours())}:${pad(now.getMinutes())}`;
  const el = document.getElementById('tanggalWaktu');
  if (el) el.textContent = tanggalString;
}

// --- OPTIMISASI 1: Fetch Quote dengan CACHING ---
// Jadi gak perlu loading ke github setiap kali klik
async function loadQuote() {
  const CACHE_KEY = 'cached_quote';
  const CACHE_TIME_KEY = 'cached_quote_time';
  const ONE_DAY = 24 * 60 * 60 * 1000; // 24 jam

  const savedQuote = localStorage.getItem(CACHE_KEY);
  const lastFetch = localStorage.getItem(CACHE_TIME_KEY);
  const now = Date.now();

  // Kalau ada cache dan umurnya belum 24 jam, pake yang di simpenan aja (INSTANT!)
  if (savedQuote && lastFetch && (now - lastFetch < ONE_DAY)) {
    quoteEl.innerText = savedQuote;
    return; // Stop, gak usah fetch
  }

  // Kalau cache kosong atau udah basi, baru fetch di background
  // Kita kasih text default dulu biar gak kosong melompong
  if(!savedQuote) quoteEl.innerText = "Loading quotes...";

  try {
    const response = await fetch("https://raw.githubusercontent.com/adityajanata/shelter/main/hop.txt", { cache: "no-store" });
    if (!response.ok) throw new Error("Gagal");
    const text = await response.text();
    
    // Simpen ke storage buat besok-besok
    localStorage.setItem(CACHE_KEY, text);
    localStorage.setItem(CACHE_TIME_KEY, now);
    quoteEl.innerText = text;
  } catch (err) {
    // Kalau gagal (offline), pake yang lama kalau ada, atau pesan default
    quoteEl.innerText = savedQuote || "Hope is a good thing."; 
  }
}

// --- LOGIC UTAMA (CLEANING & PARSING) ---
function cleanInvisibleChars(str) {
  return str.replace(/[\u00A0\u1680\u180E\u2000-\u200B\u202F\u205F\u3000\uFEFF]/g, ' ');
}

function tryParseNestedJson(value) {
  if (typeof value !== 'string') return value;
  // Optimasi: Kalau cuma angka atau bukan struktur JSON, balikin langsung
  if (/^-?\d+$/.test(value)) return value;
  if (!/^\s*[\{\[]/.test(value)) return value;

  try {
    const cleanedString = cleanInvisibleChars(value);
    const safeNestedString = cleanedString.replace(/:(\s*)(\d{15,})/g, ':$1"$2"');
    const parsed = JSON.parse(safeNestedString);
    return tryParseNestedJson(parsed);
  } catch {
    return value;
  }
}

function deepParse(obj) {
  if (typeof obj === 'string') return tryParseNestedJson(obj);
  if (Array.isArray(obj)) return obj.map(deepParse);
  if (obj && typeof obj === 'object') {
    const result = {};
    for (const key in obj) {
      if (Object.hasOwnProperty.call(obj, key)) {
        result[key] = deepParse(obj[key]);
      }
    }
    return result;
  }
  return obj;
}

function isPretty(jsonStr) {
  return /\n\s{2,}/.test(jsonStr);
}

function applySuccessStyle() {
  output.style.color = '#0f5132';
  output.style.backgroundColor = '#d1e7dd';
  output.style.borderColor = '#badbcc';
}

function applyErrorStyle() {
  output.style.color = '#842029';
  output.style.backgroundColor = '#f8d7da';
  output.style.borderColor = '#f5c2c7';
}

function resetOutputStyle() {
  output.style.color = '';
  output.style.backgroundColor = '';
  output.style.borderColor = '';
}

// --- EVENT LISTENERS ---
input.addEventListener('input', function() {
  // Pake requestAnimationFrame biar UI gak nge-lag pas ngetik cepet
  requestAnimationFrame(() => {
    try {
      let rawValue = input.value;
      if (!rawValue.trim()) { // Kalau kosong, reset
        output.value = '';
        resetOutputStyle();
        return;
      }

      let cleanedValue = cleanInvisibleChars(rawValue);
      const bigIntRegex = /:\s*(-?\d{15,})/g;
      const jsonSafe = cleanedValue.replace(bigIntRegex, ': "$1"');
      
      const obj = JSON.parse(jsonSafe);
      const fullyParsed = deepParse(obj);

      if (isPretty(input.value)) {
        output.value = JSON.stringify(fullyParsed);
      } else {
        output.value = JSON.stringify(fullyParsed, null, 2);
      }

      error.textContent = '';
      resetOutputStyle();
    } catch (e) {
      // Jangan langsung error merah pas baru ngetik 1 huruf
      if (input.value.length > 5) {
        output.value = '';
        error.textContent = 'Invalid JSON: ' + e.message;
        applyErrorStyle();
      }
    }
  });
});

formatBtn.addEventListener('click', function() {
  if (output.value) {
    navigator.clipboard.writeText(output.value)
      .then(() => {
        const originalText = formatBtn.textContent;
        formatBtn.textContent = 'Copied!';
        applySuccessStyle();
        setTimeout(() => {
          formatBtn.textContent = originalText;
          resetOutputStyle();
        }, 1500);
      })
      .catch(() => {
        error.textContent = 'Failed to copy!';
        applyErrorStyle();
      });
  }
});

// --- UPDATE CHECKER (Manual Click Only) ---
// Gak usah auto check pas load, berat-beratin aja.
async function checkForUpdate() {
  updateBtn.classList.add("spin"); // Asumsi ada CSS class spin
  
  function getBrowserType() {
    const ua = navigator.userAgent;
    if (ua.includes("Firefox")) return "firefox";
    if (ua.includes("Edg")) return "edge";
    if (ua.includes("Chrome")) return "chrome";
    return "other";
  }

  try {
    // Simulasi delay biar keliatan muter dikit (UX)
    await new Promise(r => setTimeout(r, 500)); 

    const response = await fetch("https://rapiin-json.vercel.app/extension-version.json", { cache: "no-store" });
    if (!response.ok) throw new Error("Server error");
    
    const data = await response.json();
    const latest = data.version;
    const current = chrome.runtime.getManifest().version;

    if (latest !== current) {
      if (confirm(`🔥 Versi baru tersedia!\n\nVersi kamu: ${current}\nVersi terbaru: ${latest}\n\nChangelog:\n${changelog}\n\nMau Download file yang terupdate?`)) {
        const browser = getBrowserType();
        let downloadUrl = "";
        if (browser === "firefox") {
          downloadUrl = `https://rapiin-json.vercel.app/bda2426706d544b0a717-${latest}.xpi`;
        } else if (browser === "chrome" || browser === "edge") {
          downloadUrl = `https://rapiin-json.vercel.app/rapiin_json_${latest}.zip`;
        } else {
          downloadUrl = `https://rapiin-json.vercel.app/rapiin_json_${latest}.zip`; // fallback
        }

        window.open(downloadUrl, "_blank");

      }
    } else {
      const browser = getBrowserType();
      alert(`✅ Rapiin JSON sudah versi terbaru di ${browser} kamu!`);
    }
  } catch (e) {
    console.error(e);
    alert("❌ Gagal cek update");
  } finally {
    updateBtn.classList.remove("spin");
  }
}

if(updateBtn) updateBtn.addEventListener("click", checkForUpdate);

// Ambil versi dari manifest.json
const manifestData = chrome.runtime.getManifest();
const currentVersion = manifestData.version;

// Tampilin ke label
const versionLabel = document.getElementById('version-label');
if (versionLabel) {
  versionLabel.textContent = `V${currentVersion}`;
}

// --- INITIALIZATION ---
// Pastikan script jalan setelah DOM siap (kalau script ditaruh di head)
document.addEventListener("DOMContentLoaded", () => {
  updateWaktu();
  // Load quote secara async, jangan await di sini biar UI gak block
  loadQuote(); 
});